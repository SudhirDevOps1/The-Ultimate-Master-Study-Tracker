# 🚀 Future Feature Roadmap / Suggestions

A list of high-value features that can be added next to elevate FlowTrack:

### 1. 📂 File/Notes Attachment (Session Notes)
- **Concept**: Attach PDF notes, markdown files, links, or images directly to a study session.
- **Benefit**: Keep all material references tied to the studied logs.

### 2. 🤖 Local AI Flashcards Generator
- **Concept**: Generate dynamic revision flashcards from your study session notes using local rule structures or Ollama.
- **Benefit**: Active recall integrations inside Achievements.

### 3. 📊 Daily Focus Score (Implemented!)
- **Concept**: Advanced rating calculation checking total duration studied against target, deducting distraction pauses.
- **Benefit**: Precise daily feedback rating on dashboard (0-100 score).

### 4. 📳 Background Push Notifications (Implemented!)
- **Concept**: Send OS-level push notifications utilizing background Service Worker synchronization.
- **Benefit**: Resilient alarms even if the browser tab sleeps.

---

## 🌐 Hybrid Cloud Synchronization Architecture (Firebase / Supabase)

To support seamless cross-device syncing, you can integrate a Cloud DB backup layer alongside the local IndexedDB database.

### 🏗️ Guest Mode vs Cloud Auth Flow:
1. **Guest Mode (Default)**: Users can use the application without logging in. All data is stored in the browser's IndexedDB.
2. **Cloud Sync Mode**: User logs in with Google/GitHub OAuth. The local IndexedDB is synced securely to the cloud. If the browser cache is cleared, data is safely restored from the cloud.

### 🔌 Setup and Environment Configuration (Vercel / Cloudflare):

To hook up **Supabase** or **Firebase**, add these to your `.env` workspace variables:

```bash
# Supabase Configuration
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-public-key"

# OR Firebase Configuration
VITE_FIREBASE_API_KEY="AIzaSy..."
VITE_FIREBASE_AUTH_DOMAIN="flowtrack.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="flowtrack"
```

In production (Vercel Dashboard or Cloudflare Pages Settings), add these identical keys under **Environment Variables** to bypass local settings and build securely on the server!
