import { useState, useEffect, useRef, useMemo } from "react";
import { Brain, Send, Settings2, ShieldCheck, Cpu, Bot, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Panel } from "@/components/common/Panel";
import { useAppStore, type AppState } from "@/store/useAppStore";
import type { AiConfig } from "@/types/models";
import { useStreak } from "@/hooks/useStreak";
import { toDurationLabel } from "@/utils/time";

// Lightweight markdown to JSX formatter
function Markdown({ text }: { text: string }) {
  const lines = text.split("\n");
  
  return (
    <div className="space-y-2 text-sm leading-relaxed text-slate-200">
      {lines.map((line, idx) => {
        // Headers
        if (line.startsWith("### ")) {
          return <h4 key={idx} className="text-base font-bold text-cyan-400 mt-3 mb-1">{line.slice(4)}</h4>;
        }
        if (line.startsWith("## ")) {
          return <h3 key={idx} className="text-lg font-extrabold text-cyan-300 mt-4 mb-2">{line.slice(3)}</h3>;
        }
        if (line.startsWith("# ")) {
          return <h2 key={idx} className="text-xl font-black text-white mt-4 mb-2">{line.slice(2)}</h2>;
        }

        // Bullet lists
        if (line.startsWith("- ") || line.startsWith("* ")) {
          return (
            <ul key={idx} className="list-disc list-inside pl-4 space-y-1">
              <li>{parseInlineFormatting(line.slice(2))}</li>
            </ul>
          );
        }

        // Numbered lists
        const numMatch = line.match(/^(\d+)\.\s(.*)/);
        if (numMatch) {
          return (
            <ol key={idx} className="list-decimal list-inside pl-4 space-y-1">
              <li>{parseInlineFormatting(numMatch[2])}</li>
            </ol>
          );
        }

        // Blockquotes
        if (line.startsWith("> ")) {
          return (
            <blockquote key={idx} className="border-l-4 border-cyan-500 bg-slate-950/40 p-2 pl-4 rounded-r-lg italic text-slate-400 my-2">
              {parseInlineFormatting(line.slice(2))}
            </blockquote>
          );
        }

        // Empty lines
        if (line.trim() === "") {
          return <div key={idx} className="h-1" />;
        }

        // Regular paragraph
        return <p key={idx}>{parseInlineFormatting(line)}</p>;
      })}
    </div>
  );
}

function parseInlineFormatting(text: string) {
  // Simple bold and italic parsing
  const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i} className="font-bold text-white">{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("*") && part.endsWith("*")) {
      return <em key={i} className="italic text-slate-300">{part.slice(1, -1)}</em>;
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return <code key={i} className="bg-slate-950 px-1.5 py-0.5 rounded text-xs text-pink-400 font-mono">{part.slice(1, -1)}</code>;
    }
    return part;
  });
}

const PROVIDERS = [
  { id: "local_rules", name: "Local AI Rules (Free & Private)", needsKey: false },
  { id: "gemini", name: "Google Gemini", needsKey: true, defaultModel: "gemini-1.5-flash" },
  { id: "cerebras", name: "Cerebras API (Ultra-Fast)", needsKey: true, defaultModel: "llama3.1-8b" },
  { id: "openai", name: "OpenAI ChatGPT", needsKey: true, defaultModel: "gpt-4o-mini" },
  { id: "mistral", name: "Mistral AI", needsKey: true, defaultModel: "mistral-tiny" },
  { id: "grok", name: "xAI Grok", needsKey: true, defaultModel: "grok-beta" },
  { id: "groq", name: "Groq Cloud", needsKey: true, defaultModel: "llama-3.3-70b-versatile" },
  { id: "ollama", name: "Ollama (Local Offline)", needsKey: false, defaultModel: "llama3" }
];

const HARDWARE_PROFILES = [
  { id: "cpu", name: "CPU Only / Low RAM (phi3 / qwen2.5:1.5b)", suggestion: "phi3:latest" },
  { id: "mid", name: "8GB RAM + Mid GPU (llama3:8b / gemma2:9b)", suggestion: "llama3:latest" },
  { id: "high", name: "16GB+ RAM + Apple M-Chip/RTX GPU (qwen2.5:14b)", suggestion: "qwen2.5:14b" }
];

export function AIAssistantPage() {
  const sessions = useAppStore((state: AppState) => state.sessions);
  const subjects = useAppStore((state: AppState) => state.subjects);
  const dailyGoalHours = useAppStore((state: AppState) => state.dailyGoalHours);
  const weeklyTargetHours = useAppStore((state: AppState) => state.weeklyTargetHours);
  const profile = useAppStore((state: AppState) => state.profile);
  const aiConfig = useAppStore((state: AppState) => state.aiConfig);
  const setAiConfig = useAppStore((state: AppState) => state.setAiConfig);
  const streakData = useStreak();

  const [provider, setProvider] = useState<AiConfig["provider"]>(aiConfig?.provider ?? "local_rules");
  const [apiKey, setApiKey] = useState(aiConfig?.apiKey ?? "");
  const [model, setModel] = useState(aiConfig?.model ?? "local-rules");
  const [ollamaUrl, setOllamaUrl] = useState(aiConfig?.ollamaUrl ?? "http://localhost:11434");
  
  const [showConfig, setShowConfig] = useState(false);
  const [hardwareSuggestion, setHardwareSuggestion] = useState("");
  const [detectedModels, setDetectedModels] = useState<string[]>([]);
  const [detecting, setDetecting] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([
    {
      role: "assistant",
      content: `Hello ${profile?.name || "there"}! I am your FlowTrack AI Study Assistant. I have read your study logs, goals, and profiles. Ask me anything about your study patterns, or select one of the suggested prompts below! 📚✨`
    }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const saveSettings = async () => {
    await setAiConfig({ provider, apiKey, model, ollamaUrl });
    setStatusMessage("AI Settings saved locally!");
    setTimeout(() => setStatusMessage(""), 2500);
  };

  const handleOllamaDetect = async () => {
    setDetecting(true);
    try {
      const res = await fetch(`${ollamaUrl}/api/tags`);
      const data = await res.json();
      if (data.models) {
        const names = data.models.map((m: any) => m.name);
        setDetectedModels(names);
        if (names.length > 0) {
          setModel(names[0]);
        }
        setStatusMessage(`Successfully detected ${names.length} local models!`);
      }
    } catch (e) {
      setStatusMessage("Ollama connection failed. Ensure Ollama is running & CORS is enabled.");
    }
    setDetecting(false);
    setTimeout(() => setStatusMessage(""), 4000);
  };

  // Prepares the study stats context to supply to LLMs
  const studyContext = useMemo(() => {
    const totalHours = sessions.reduce((sum, s) => sum + s.actualSeconds, 0) / 3600;
    const completed = sessions.filter(s => s.status === "completed");
    
    const subjectMap: Record<string, number> = {};
    sessions.forEach(s => {
      const sub = subjects.find(sub => sub.id === s.subjectId);
      if (sub && s.actualSeconds > 0) {
        subjectMap[sub.name] = (subjectMap[sub.name] ?? 0) + s.actualSeconds / 3600;
      }
    });

    const recentList = sessions
      .slice(0, 8)
      .map(s => {
        const sub = subjects.find(sub => sub.id === s.subjectId);
        return `- ${sub?.name || "Deleted subject"}: ${toDurationLabel(Math.round(s.actualSeconds/60))} studied (Date: ${new Date(s.startTime).toLocaleDateString()}) ${s.notes ? `[Notes: ${s.notes}]` : ""}`;
      })
      .join("\n");

    return {
      userName: profile?.name || "User",
      userAge: profile?.age || "Not specified",
      userProfession: profile?.profession || "Student",
      userGoal: profile?.goal || "Learn & Focus",
      dailyGoalHours,
      weeklyTargetHours,
      totalHours: totalHours.toFixed(1),
      dailyStreak: streakData.daily,
      longestStreak: streakData.longestStreak,
      completedCount: completed.length,
      subjectsStudied: Object.entries(subjectMap).map(([name, hr]) => `${name}: ${hr.toFixed(1)} hours`).join(", "),
      recentActivity: recentList
    };
  }, [sessions, subjects, dailyGoalHours, weeklyTargetHours, profile, streakData]);

  // Local Rule-Based simulated AI engine for 100% offline free query
  const getLocalRuleResponse = (query: string): string => {
    const q = query.toLowerCase();
    const name = studyContext.userName;
    const subjectsList = subjects.map(s => s.name).join(", ");
    
    if (q.includes("why") && q.includes("less") || q.includes("kam padha") || q.includes("inconsistent")) {
      return `### 📊 Study Consistency Analysis for **${name}**\n\nLooking at your recent study sessions, you studied a total of **${studyContext.totalHours} hours** across your subjects.\n\nHere are some reasons why study output might be dropping:\n1. **Lack of scheduling**: You have planned sessions but the gap between them might be too large. Try setting a standard study routine.\n2. **Neglected subjects**: You studied **${studyContext.subjectsStudied || "no subjects yet"}**. If you focus on only one topic, you get burned out. Try shuffling subjects!\n\n**💡 Actionable Tip**: Start a small 15-minute study block today in **Strict Focus mode** to restart your momentum.`;
    }

    if (q.includes("time") || q.includes("hour") || q.includes("kb padhu") || q.includes("peak") || q.includes("when")) {
      return `### ⚡ Optimal Focus Window Analysis\n\nHi **${name}**, let's look at your study timings:\n- **Your daily goal**: ${studyContext.dailyGoalHours} hours.\n- **Your current streak**: ${studyContext.dailyStreak} days.\n\nBased on focus tracking, studying early in the morning (before 9 AM) or splitting study into two halves (e.g. 10 AM - 12 PM and 4 PM - 6 PM) produces the highest focus duration. \n\n**💡 Actionable Tip**: Use the **Pomodoro mode** in FlowTrack during your focus session. Set it to 25 mins focus and 5 mins break to maintain brain energy!`;
    }

    if (q.includes("plan") || q.includes("routine") || q.includes("subjects") || q.includes("suggest")) {
      return `### 📅 Personalized Study Routine for **${name}**\n\nYour primary goal is: *"${studyContext.userGoal}"* as a **${studyContext.userProfession}**.\n\nHere is a suggested plan based on your subjects (**${subjectsList || "No subjects added yet"}**):\n1. **Morning Block (45 mins)**: Focus on revision and high-difficulty topics first.\n2. **Midday Block (60 mins)**: Hands-on practice, coding, math, or notes writing.\n3. **Evening Block (30 mins)**: Light revision, planning tomorrow's sessions.\n\nMake sure to carry forward sessions automatically so you have a planned template ready every day!`;
    }

    // Default reply
    return `### 🤖 Study Assistant Insights\n\nThank you for asking, **${name}**! Here is a summary of your stats:\n- **All Time Hours**: ${studyContext.totalHours} hours\n- **Completed Sessions**: ${studyContext.completedCount} focus blocks\n- **Streak**: ${studyContext.dailyStreak} days\n- **Subjects tracked**: ${studyContext.subjectsStudied || "None yet"}\n\n**💡 Recommended Study Tip**: Try to study at least 1 hour daily to maintain your **${studyContext.dailyStreak} days streak**. Focus on *${subjects[0]?.name || "your primary subject"}* tomorrow morning. Ask me more questions about your focus to get targeted advice!`;
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    
    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    setLoading(true);

    try {
      if (provider === "local_rules") {
        // Run rule-based analysis locally
        setTimeout(() => {
          const reply = getLocalRuleResponse(userMessage);
          setMessages(prev => [...prev, { role: "assistant", content: reply }]);
          setLoading(false);
        }, 1200);
        return;
      }

      // Prepare context block
      const systemPrompt = `You are a helpful, professional, and private AI study coach. Analyze the user's study patterns and give actionable advice. Speak in English (or Hindi if requested), keep answers concise, and format heavily with Markdown headers.
      User Profile:
      - Name: ${studyContext.userName}
      - Age: ${studyContext.userAge}
      - Profession/Exam: ${studyContext.userProfession}
      - Primary Goal: ${studyContext.userGoal}
      
      Study Stats:
      - Daily Goal: ${studyContext.dailyGoalHours} hours
      - Weekly Target: ${studyContext.weeklyTargetHours} hours
      - Current Streak: ${studyContext.dailyStreak} days
      - Longest Streak: ${studyContext.longestStreak} days
      - Total Hours Studied: ${studyContext.totalHours}h
      - Subjects breakdown: ${studyContext.subjectsStudied}
      
      Recent Activity Logs:
      ${studyContext.recentActivity}`;

      let reply = "";

      if (provider === "gemini") {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model || "gemini-1.5-flash"}:generateContent?key=${apiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              { role: "user", parts: [{ text: `${systemPrompt}\n\nUser Question: ${userMessage}` }] }
            ]
          })
        });
        const data = await res.json();
        reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "Unable to fetch response from Gemini. Check API Key or model.";
      } 
      else if (provider === "openai" || provider === "cerebras" || provider === "mistral" || provider === "grok" || provider === "ollama" || provider === "groq") {
        let endpoint = "";
        let authHeader = `Bearer ${apiKey}`;
        
        switch (provider) {
          case "openai": endpoint = "https://api.openai.com/v1/chat/completions"; break;
          case "cerebras": endpoint = "https://api.cerebras.ai/v1/chat/completions"; break;
          case "mistral": endpoint = "https://api.mistral.ai/v1/chat/completions"; break;
          case "grok": endpoint = "https://api.x.ai/v1/chat/completions"; break;
          case "groq": endpoint = "https://api.groq.com/openai/v1/chat/completions"; break;
          case "ollama": 
            endpoint = `${ollamaUrl}/v1/chat/completions`; 
            authHeader = ""; 
            break;
        }

        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (authHeader) headers["Authorization"] = authHeader;

        const res = await fetch(endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify({
            model: model || (provider === "ollama" ? "llama3" : provider === "groq" ? "llama-3.3-70b-versatile" : "gpt-4o-mini"),
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userMessage }
            ],
            temperature: 0.5
          })
        });
        const data = await res.json();
        reply = data.choices?.[0]?.message?.content || "No choices returned from model API. Verify model configuration.";
      }

      setMessages(prev => [...prev, { role: "assistant", content: reply }]);

    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: "assistant", content: `❌ **API Connection Error**: Failed to fetch AI answer. Please verify your internet connection, API Key, and model name. Alternatively, switch to **Local AI Rules** in settings for offline private tips!` }]);
    }
    setLoading(false);
  };

  const handleSuggestionClick = (promptText: string) => {
    setInput(promptText);
  };

  return (
    <div className="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
      {/* Left Column: Chat Assistant */}
      <Panel className="flex flex-col h-[75vh] min-h-[500px]">
        {/* Chat Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-xl shadow-lg text-slate-950">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">AI Study Assistant</h3>
              <p className="text-xs text-slate-400 font-medium italic">
                {provider === "local_rules" ? "Local Rules Engine • 100% Private Offline" : `Powered by ${PROVIDERS.find(p => p.id === provider)?.name}`}
              </p>
            </div>
          </div>
          
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="flex items-center gap-1.5 rounded-xl border border-white/15 px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-white/5"
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>AI Setup</span>
          </button>
        </div>

        {/* Message Container */}
        <div className="flex-1 overflow-y-auto pr-2 space-y-4 pretty-scrollbar">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex items-start gap-3 max-w-[85%] ${
                msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
              }`}
            >
              <div className={`p-2 rounded-xl text-xs ${
                msg.role === "user" ? "bg-cyan-500 text-slate-950 font-bold" : "bg-white/10 text-cyan-300"
              }`}>
                {msg.role === "user" ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
              </div>
              <div className={`rounded-2xl p-4 border ${
                msg.role === "user" 
                  ? "bg-cyan-500/10 border-cyan-500/30 text-white rounded-tr-none" 
                  : "bg-slate-900/50 border-white/5 text-slate-200 rounded-tl-none"
              }`}>
                {msg.role === "assistant" ? <Markdown text={msg.content} /> : <p className="text-sm font-medium">{msg.content}</p>}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-start gap-3 max-w-[80%]">
              <div className="p-2 rounded-xl bg-white/10 text-cyan-300">
                <Bot className="w-3.5 h-3.5 animate-pulse" />
              </div>
              <div className="rounded-2xl p-4 bg-slate-900/50 border border-white/5 text-slate-400 text-sm flex items-center gap-3">
                <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
                <span>AI Assistant is analyzing focus logs...</span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Suggestions Panel */}
        {messages.length === 1 && (
          <div className="py-3 space-y-2">
            <p className="text-xs font-semibold text-slate-400">💡 Suggested Prompts:</p>
            <div className="flex flex-wrap gap-2">
              {[
                { label: "Why did I study less?", text: "Why did I study less this week? Give me an analysis based on my subjects." },
                { label: "Optimize my schedule", text: "When is my peak study time? Analyze my sessions and recommend when to study." },
                { label: "Create revision plan", text: "Generate a custom 3-day revision routine for my subjects." }
              ].map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSuggestionClick(p.text)}
                  className="rounded-xl border border-white/5 bg-white/5 px-3 py-2 text-xs font-medium text-slate-300 hover:bg-white/10 text-left transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Bar */}
        <div className="pt-3 border-t border-white/10 mt-2 flex gap-2">
          <input
            type="text"
            placeholder="Ask AI study coach a question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            className="flex-1 rounded-2xl border border-white/15 bg-slate-950/70 px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 p-3 px-5 text-slate-950 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:hover:scale-100 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </Panel>

      {/* Right Column: Configurations & Model Guides */}
      <AnimatePresence>
        {(showConfig || window.innerWidth >= 1280) && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-5"
          >
            {/* AI Setup Config Panel */}
            <Panel className="space-y-4">
              <div className="flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg font-bold text-white">AI Setup Configuration</h3>
              </div>
              
              <div className="space-y-2">
                <label className="block text-xs text-slate-400 font-semibold uppercase">Provider</label>
                <select
                  value={provider}
                  onChange={(e) => {
                    const prov = e.target.value as AiConfig["provider"];
                    setProvider(prov);
                    const matched = PROVIDERS.find(p => p.id === prov);
                    if (matched) {
                      setModel(matched.defaultModel || "");
                    }
                  }}
                  className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                >
                  {PROVIDERS.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              {PROVIDERS.find(p => p.id === provider)?.needsKey && (
                <div className="space-y-2">
                  <label className="block text-xs text-slate-400 font-semibold uppercase">API Key</label>
                  <input
                    type="password"
                    placeholder="Paste your API key here..."
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                  <p className="text-[10px] text-slate-500 italic">API Key is saved securely in local IndexedDB only.</p>
                </div>
              )}

              {provider === "ollama" && (
                <div className="space-y-2 border border-white/5 rounded-xl p-3 bg-white/5">
                  <label className="block text-xs text-slate-400 font-semibold uppercase">Ollama Local URL</label>
                  <input
                    type="text"
                    value={ollamaUrl}
                    onChange={(e) => setOllamaUrl(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-1.5 text-xs text-white"
                  />
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={handleOllamaDetect}
                      disabled={detecting}
                      className="rounded-lg bg-cyan-500/10 border border-cyan-400/30 px-3 py-1 text-xs text-cyan-300 font-bold hover:bg-cyan-500/20"
                    >
                      {detecting ? "Checking..." : "🔄 Auto-Detect Models"}
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="block text-xs text-slate-400 font-semibold uppercase">Model Name</label>
                {provider === "ollama" && detectedModels.length > 0 ? (
                  <select
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white"
                  >
                    {detectedModels.map(name => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    placeholder="Enter model identifier..."
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                )}
              </div>

              <div className="flex items-center justify-between gap-3 pt-2">
                <span className="text-xs text-emerald-400 font-medium">{statusMessage}</span>
                <button
                  onClick={saveSettings}
                  className="rounded-xl bg-gradient-to-r from-indigo-500 to-cyan-500 px-5 py-2 text-xs font-bold text-white shadow-lg hover:scale-105 transition-transform"
                >
                  Save Settings
                </button>
              </div>
            </Panel>

            {/* Hardware-Based Model Suggestions */}
            <Panel className="space-y-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">Ollama Local Model Suggestions</h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Suggesting local models to pull based on your computer hardware profile:
              </p>
              
              <div className="space-y-2">
                <label className="block text-xs text-slate-500 font-semibold">Select Hardware Profile</label>
                <select
                  value={hardwareSuggestion}
                  onChange={(e) => {
                    const prof = HARDWARE_PROFILES.find(p => p.id === e.target.value);
                    if (prof) {
                      setHardwareSuggestion(e.target.value);
                      if (provider === "ollama") setModel(prof.suggestion);
                    }
                  }}
                  className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-1.5 text-xs text-white"
                >
                  <option value="">Choose Profile</option>
                  {HARDWARE_PROFILES.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              <div className="rounded-xl bg-white/5 border border-white/10 p-3 space-y-2">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1">
                  💡 How to download & run Ollama:
                </span>
                <ol className="list-decimal list-inside text-[11px] text-slate-400 space-y-1">
                  <li>Download Ollama from <a href="https://ollama.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">ollama.com</a></li>
                  <li>Run command: `ollama run llama3` (or phi3)</li>
                  <li>Enable local browser access by setting the environment variable `OLLAMA_ORIGINS=*` before starting Ollama.</li>
                </ol>
              </div>
            </Panel>

            {/* Privacy Shield Info */}
            <Panel className="border border-emerald-500/10 bg-emerald-950/5 p-4 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400">
                <ShieldCheck className="w-5 h-5" />
                <h3 className="text-sm font-bold">Privacy Guaranteed</h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                All AI credentials and keys are strictly saved locally inside your browser's IndexedDB. Study logs are never transmitted anywhere except to your configured API endpoints. Select **Local AI Rules** or **Ollama** for 100% private offline operations.
              </p>
            </Panel>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
