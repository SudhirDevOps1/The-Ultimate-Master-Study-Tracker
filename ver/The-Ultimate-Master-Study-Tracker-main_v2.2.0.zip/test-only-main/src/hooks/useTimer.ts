import { useEffect, useMemo, useState } from "react";
import { useAppStore } from "@/store/useAppStore";


export function useTimer() {
  const timer = useAppStore((state) => state.timer);
  const sessions = useAppStore((state) => state.sessions);
  const strictFocusMode = useAppStore((state) => state.strictFocusMode);
  const pauseSession = useAppStore((state) => state.pauseSession);
  const setHiddenAt = useAppStore((state) => state.setHiddenAt);
  const markTimerInteraction = useAppStore((state) => state.markTimerInteraction);
  const getActiveElapsed = useAppStore((state) => state.getActiveElapsed);
  const syncActiveSession = useAppStore((state) => state.syncActiveSession);
  const [nowMs, setNowMs] = useState(Date.now());

  useEffect(() => {
    const tick = () => {
      const now = Date.now();
      setNowMs(now);

      // Strict Focus Mode inactivity check
      const state = useAppStore.getState();
      const currentTimer = state.timer;
      if (
        state.strictFocusMode &&
        currentTimer.activeSessionId &&
        !currentTimer.isPaused &&
        currentTimer.lastInteractionAtMs
      ) {
        const inactiveMs = now - currentTimer.lastInteractionAtMs;
        if (inactiveMs >= 10 * 60 * 1000) { // 10 minutes
          void state.pauseSession();
          if (state.notificationsEnabled && typeof Notification !== "undefined" && Notification.permission === "granted") {
            new Notification("FlowTrack - Inactivity Auto-Pause", {
              body: "Your study session was auto-paused due to 10 minutes of inactivity. Stay focused! 🔒",
              icon: "/icon-192.png",
            });
          }
        }
      }

      void syncActiveSession(now);
    };

    tick();
    const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, [syncActiveSession]);

  useEffect(() => {
    const onVisibleInteraction = () => {
      if (document.hidden) return;
      void markTimerInteraction(Date.now());
      setNowMs(Date.now());
    };

    const updateVisibility = () => {
      const isPipActive = useAppStore.getState().isPipActive;
      
      if (document.hidden) {
        void setHiddenAt(Date.now());
        void syncActiveSession(Date.now());
        
        // Immediate pause if NOT in PiP mode
        if (!isPipActive) {
          void pauseSession();
        }
        return;
      }

      // If we were hidden but PiP kept us alive, just clear hiddenAt
      void setHiddenAt(null);
      void markTimerInteraction(Date.now());
      void syncActiveSession(Date.now());
      setNowMs(Date.now());
    };

    const syncOnExit = () => {
      void syncActiveSession(Date.now());
    };

    const syncOnFocus = () => {
      void markTimerInteraction(Date.now());
      void syncActiveSession(Date.now());
      setNowMs(Date.now());
    };

    const interactionEvents: Array<keyof WindowEventMap> = ["pointerdown", "keydown", "mousemove", "touchstart", "wheel"];

    document.addEventListener("visibilitychange", updateVisibility);
    window.addEventListener("pagehide", syncOnExit);
    window.addEventListener("focus", syncOnFocus);
    interactionEvents.forEach((eventName) => window.addEventListener(eventName, onVisibleInteraction, { passive: true }));

    return () => {
      document.removeEventListener("visibilitychange", updateVisibility);
      window.removeEventListener("pagehide", syncOnExit);
      window.removeEventListener("focus", syncOnFocus);
      interactionEvents.forEach((eventName) => window.removeEventListener(eventName, onVisibleInteraction));
    };
  }, [markTimerInteraction, pauseSession, setHiddenAt, strictFocusMode, syncActiveSession]);

  useEffect(() => {
    let activeInterval: number | undefined;

    const pollActiveWindow = async () => {
      const state = useAppStore.getState();
      if (state.timer.activeSessionId && !state.timer.isPaused) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 1500);
          const res = await fetch("http://localhost:5001/active-window", { signal: controller.signal });
          clearTimeout(timeoutId);
          const data = await res.json();
          if (data && typeof data.title === "string") {
            state.setActiveWindow(data.title);
          }
        } catch {
          state.setActiveWindow("");
        }
      } else {
        state.setActiveWindow("");
      }
    };

    activeInterval = window.setInterval(pollActiveWindow, 5000);
    void pollActiveWindow();

    return () => {
      if (activeInterval) {
        window.clearInterval(activeInterval);
      }
    };
  }, []);

  const activeSession = useMemo(
    () => sessions.find((session) => session.id === timer.activeSessionId) ?? null,
    [sessions, timer.activeSessionId]
  );

  const elapsedSeconds = getActiveElapsed(nowMs);
  const plannedSeconds = (activeSession?.plannedMinutes ?? 0) * 60;
  const remainingSeconds = Math.max(0, plannedSeconds - elapsedSeconds);
  const progress = plannedSeconds > 0 ? Math.min(100, (elapsedSeconds / plannedSeconds) * 100) : 0;

  return { activeSession, elapsedSeconds, remainingSeconds, progress };
}
