import React, { useState, useEffect, useRef } from "react";
import { Volume2, VolumeX, CloudRain, TreePine, Coffee, Hash, ChevronDown, Play, Pause, FolderOpen, Link2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAppStore, type AppState } from "@/store/useAppStore";

const SOUNDS = [
  { 
    id: "rain", 
    name: "Rain Loops", 
    icon: <CloudRain className="w-4 h-4" />, 
    url: "https://raw.githubusercontent.com/karthiknvd/noctune/main/sounds/rain.mp3" 
  },
  { 
    id: "forest", 
    name: "Forest Birds", 
    icon: <TreePine className="w-4 h-4" />, 
    url: "https://raw.githubusercontent.com/karthiknvd/noctune/main/sounds/forest.mp3" 
  },
  { 
    id: "lofi", 
    name: "Synth Melody", 
    icon: <Coffee className="w-4 h-4" />, 
    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" 
  },
  { 
    id: "white_noise", 
    name: "River Streams", 
    icon: <Hash className="w-4 h-4" />, 
    url: "https://raw.githubusercontent.com/karthiknvd/noctune/main/sounds/river.mp3" 
  },
  {
    id: "local",
    name: "Local Audio File",
    icon: <FolderOpen className="w-4 h-4" />,
    url: ""
  },
  {
    id: "youtube",
    name: "YouTube / Link",
    icon: <Link2 className="w-4 h-4" />,
    url: ""
  }
];

export function AmbiencePlayer() {
  const isMusicEnabled = useAppStore((state: AppState) => state.focusMusicEnabled);
  const setFocusMusicEnabled = useAppStore((state: AppState) => state.setFocusMusicEnabled);
  
  const [selectedTrack, setSelectedTrack] = useState(SOUNDS[0]);
  const [volume, setVolume] = useState(0.5);
  const [isOpen, setIsOpen] = useState(false);
  
  const [localUrl, setLocalUrl] = useState<string>("");
  const [localFileName, setLocalFileName] = useState<string>("");
  const [webUrl, setWebUrl] = useState<string>("");
  const [isUrlInputOpen, setIsUrlInputOpen] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  useEffect(() => {
    if (isMusicEnabled) {
      if (selectedTrack.id === "local" && localUrl) {
        if (audioRef.current) {
          audioRef.current.src = localUrl;
          audioRef.current.load();
        }
      } else if (selectedTrack.id === "youtube" && webUrl && !getYoutubeId(webUrl)) {
        if (audioRef.current) {
          audioRef.current.src = webUrl;
          audioRef.current.load();
        }
      } else if (selectedTrack.url) {
        if (audioRef.current) {
          audioRef.current.src = selectedTrack.url;
          audioRef.current.load();
        }
      }
      
      // Attempt play
      audioRef.current?.play().catch(e => {
        console.log("Audio play blocked, waiting for user interaction.", e);
      });
    } else {
      audioRef.current?.pause();
    }
  }, [isMusicEnabled, selectedTrack, localUrl, webUrl]);

  // Clean up object URLs to prevent leaks
  useEffect(() => {
    return () => {
      if (localUrl) {
        URL.revokeObjectURL(localUrl);
      }
    };
  }, [localUrl]);

  const handleLocalFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (localUrl) {
        URL.revokeObjectURL(localUrl);
      }
      const url = URL.createObjectURL(file);
      setLocalUrl(url);
      setLocalFileName(file.name);
      setFocusMusicEnabled(true);
    }
  };

  const getYoutubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const videoId = getYoutubeId(webUrl);

  return (
    <div className="flex flex-col gap-2 relative">
      <div className="flex items-center gap-2 bg-slate-900/60 border border-white/10 rounded-2xl p-1.5 px-3 backdrop-blur-xl">
        {/* Play/Pause Button */}
        <button
          onClick={() => setFocusMusicEnabled(!isMusicEnabled)}
          className={`flex items-center justify-center p-2 rounded-xl transition-all ${
            isMusicEnabled 
              ? "bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20" 
              : "bg-white/5 text-slate-300 hover:bg-white/10"
          }`}
          title={isMusicEnabled ? "Pause Ambience" : "Play Ambience"}
        >
          {isMusicEnabled ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>

        {/* Sound Selection Button */}
        <div className="relative">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-2 hover:bg-white/5 rounded-xl px-2.5 py-2 transition-colors text-slate-300 hover:text-white"
          >
            <div className="text-cyan-400">
              {selectedTrack.icon}
            </div>
            <span className="text-sm font-semibold max-w-[95px] truncate">
              {selectedTrack.id === "local" && localFileName ? localFileName : selectedTrack.name}
            </span>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Dropdown Menu */}
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute top-full mt-2 left-0 w-52 bg-slate-950/95 backdrop-blur-xl border border-white/15 rounded-xl shadow-2xl z-[999] overflow-hidden"
              >
                {SOUNDS.map((track) => (
                  <button
                    key={track.id}
                    onClick={() => {
                      setSelectedTrack(track);
                      setIsOpen(false);
                      if (track.id === "local") {
                        fileInputRef.current?.click();
                      } else if (track.id === "youtube") {
                        setIsUrlInputOpen(true);
                      } else {
                        setIsUrlInputOpen(false);
                      }
                    }}
                    className={`flex items-center gap-3 w-full p-3 text-sm text-left transition-colors hover:bg-white/10 ${
                      selectedTrack.id === track.id ? "text-cyan-400 bg-white/5" : "text-slate-300"
                    }`}
                  >
                    <div className={`${selectedTrack.id === track.id ? "text-cyan-400" : "text-slate-500"}`}>
                      {track.icon}
                    </div>
                    <span className="font-semibold">{track.name}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-[1px] h-6 bg-white/10 mx-1" />

        {/* Volume Controls */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setVolume(v => v === 0 ? 0.5 : 0)}
            className="text-slate-400 hover:text-white transition-colors p-1"
          >
            {volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="w-16 h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-500"
          />
        </div>
      </div>

      {/* Hidden file input for Local Audio */}
      <input 
        ref={fileInputRef}
        type="file" 
        accept="audio/*" 
        className="hidden" 
        onChange={handleLocalFileChange}
      />

      {/* YouTube / Custom Web Link Input Modal / Input Field */}
      {selectedTrack.id === "youtube" && isUrlInputOpen && (
        <div className="flex flex-col gap-2 p-3 bg-slate-900/90 border border-white/10 rounded-2xl w-full max-w-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400">YouTube or Audio Link</span>
            <button onClick={() => setIsUrlInputOpen(false)} className="text-xs text-slate-500 hover:text-white">✕ Hide</button>
          </div>
          <input
            type="text"
            placeholder="Paste YouTube or direct MP3 link..."
            value={webUrl}
            onChange={(e) => {
              setWebUrl(e.target.value);
              setFocusMusicEnabled(true);
            }}
            className="w-full bg-slate-950 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400"
          />
        </div>
      )}

      {/* Embedded YouTube video card if videoId exists and music is enabled */}
      {selectedTrack.id === "youtube" && videoId && isMusicEnabled && (
        <div className="overflow-hidden rounded-2xl border border-white/10 bg-slate-950/90 p-1 shadow-2xl z-20 w-full max-w-xs absolute top-full mt-2">
          <div className="flex items-center justify-between p-1 px-2">
            <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400">📺 Focus Video Embed</span>
            <button onClick={() => setFocusMusicEnabled(false)} className="text-[10px] text-rose-400 font-bold hover:underline">Pause</button>
          </div>
          <iframe
            width="100%"
            height="150"
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=0&loop=1&playlist=${videoId}`}
            title="Focus YouTube Stream"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            sandbox="allow-same-origin allow-scripts allow-presentation"
            className="rounded-xl"
          ></iframe>
        </div>
      )}

      {/* HTML5 Audio element for standard looping tracks */}
      <audio
        ref={audioRef}
        loop
      />
    </div>
  );
}
