@echo off
title FlowTrack - Local Workspace Launcher
echo ===================================================
echo        FlowTrack Local Workspace Launcher
echo ===================================================
echo.

:: Check Node.js installation
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in your system PATH.
    echo FlowTrack requires Node.js to run the web application.
    echo Please download and install Node.js from https://nodejs.org/
    echo.
    pause
    exit /b
)

:: Check Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] Python is not installed or not in your PATH.
    echo Local active window tracking will be disabled.
    goto start_node
)

echo [INFO] Python detected. Setting up virtual environment...
if not exist .venv (
    echo [INFO] Creating Python virtual environment...
    python -m venv .venv
)

echo [INFO] Activating virtual environment & installing dependencies...
call .venv\Scripts\activate.bat
pip install --quiet pywin32 psutil

echo [INFO] Starting Local Activity Tracker in background on port 5001...
:: Explicitly execute python inside the virtual environment to ensure libraries are loaded
start "FlowTrack Activity Tracker" cmd /c ".venv\Scripts\python.exe activity_tracker.py"

:start_node
echo.
echo [INFO] Checking Node.js dependencies...
if not exist node_modules (
    echo [INFO] Installing Node packages...
    npm install
)

echo [INFO] Starting Vite development server...
echo [INFO] FlowTrack will open in your default browser shortly.
start "" http://localhost:5173
npm run dev

pause
