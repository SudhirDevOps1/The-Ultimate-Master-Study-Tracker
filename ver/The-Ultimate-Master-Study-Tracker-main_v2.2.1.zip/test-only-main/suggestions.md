# 🚀 Future Feature Roadmap / Suggestions

A list of high-value features that can be added next to elevate FlowTrack:

### 1. 📂 File/Notes Attachment (Session Notes)
- **Concept**: Attach PDF notes, markdown files, links, or images directly to a study session.
- **Benefit**: Keep all material references tied to the studied logs.

### 2. 🤖 Local AI Flashcards Generator
- **Concept**: Generate dynamic revision flashcards from your study session notes using local rule structures or Ollama.
- **Benefit**: Active recall integrations inside Achievements.

### 3. 📊 Daily Focus Score (Implemented!)
- **Concept**: Advanced rating calculation checking total duration studied against target, deducting distraction pauses.
- **Benefit**: Precise daily feedback rating on dashboard (0-100 score).

### 4. 📳 Background Push Notifications (Implemented!)
- **Concept**: Send OS-level push notifications utilizing background Service Worker synchronization.
- **Benefit**: Resilient alarms even if the browser tab sleeps.
